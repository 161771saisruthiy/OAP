package com.cap.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cap.model.Adminbean;
import com.cap.model.UploadFile;
import com.cap.model.UserReq;

public class LoginDaoImp implements ILoginDao {

	@Override
	public boolean checkAdmin(Adminbean loginBean) {
		String sql="select * from admin where id=? and passwd=?";

		try(PreparedStatement ps =getSQLConnection().prepareStatement(sql);){

			ps.setString(1, loginBean.getUsername());
			ps.setString(2, loginBean.getPassword());
			ResultSet rs =ps.executeQuery();
			if(rs.next()) {
				return true;

			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;

		
	}

	private Connection getSQLConnection() {
		
		Connection con=null;
		try{


			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/oap","root","India123");
			return con;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}catch(Exception e1) {
			e1.printStackTrace();
		}

		return con;
	}

	@Override
	public UserReq createRequest(UserReq user) throws SQLException {

       String sql="insert into user values(?,?,?,?,?)";		
       try(PreparedStatement pst = getSQLConnection().prepareStatement(sql);){
    	   pst.setString(1,user.getUserName());
    	   pst.setString(2,user.getFirstname());
    	   pst.setString(3,user.getLastname());
    	   pst.setString(4,user.getEmail());
    	   pst.setString(5,user.getPassword());
    	   int count=pst.executeUpdate();
			if(count>0) {
				return user;
			}

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean checkUser(String username,String password) {
		String sql="select * from user where username=? and passwd=?";

		try(PreparedStatement ps =getSQLConnection().prepareStatement(sql);){

			ps.setString(1,username);
			ps.setString(2, password);
			ResultSet rs =ps.executeQuery();
			if(rs.next()) {
				return true;

			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;

		
	}

	@Override
	public boolean uploadfile(UploadFile loadfile) {

	       String sql="insert into upload values(?,?)";		
	       try(PreparedStatement pst = getSQLConnection().prepareStatement(sql);){
	    	   pst.setString(1,loadfile.getAsname());
	    	   //System.out.println(loadfile.getFilepart());
	    	   FileInputStream file=new FileInputStream(loadfile.getFilepart());
	    	   pst.setBlob(2,file);
	    	   int count=pst.executeUpdate();
				if(count>0) {
					return true;
				}

			}catch(SQLException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			return false;
	}

}
