package com.cap.service;

import java.io.File;
import java.sql.SQLException;

import com.cap.dao.ILoginDao;
import com.cap.dao.LoginDaoImp;
import com.cap.model.Adminbean;
import com.cap.model.UploadFile;
import com.cap.model.UserReq;

public class LoginServiceImpl implements ILoginService {

	ILoginDao logindao=new LoginDaoImp();
	@Override
	public boolean checkAdmin(Adminbean loginBean) {
		
		return logindao.checkAdmin(loginBean);
	}
	@Override
	public UserReq createRequest(UserReq user) throws SQLException {
		
		return logindao.createRequest(user);
	}
	@Override
	public boolean checkUser(String username,String password) {
		return logindao.checkUser(username,password);
	}
	@Override
	public boolean uploadfile(UploadFile loadfile) {
		
		
		return logindao.uploadfile(loadfile);
	}

	
	
}
