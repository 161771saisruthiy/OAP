package com.cap.service;

import java.io.File;
import java.sql.SQLException;

import com.cap.model.Adminbean;
import com.cap.model.UploadFile;
import com.cap.model.UserReq;

public interface ILoginService {

	public abstract boolean checkAdmin(Adminbean loginBean);
	public abstract UserReq createRequest(UserReq user) throws SQLException;
	public abstract boolean checkUser(String username,String password);
    public abstract boolean uploadfile(UploadFile loadfile);
	
	
}
