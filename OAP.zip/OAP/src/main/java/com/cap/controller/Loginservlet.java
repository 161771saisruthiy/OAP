package com.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cap.model.Adminbean;
import com.cap.service.ILoginService;
import com.cap.service.LoginServiceImpl;


@WebServlet(name = "LoginServlet", urlPatterns = { "/LoginServlet" })
public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Loginservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String username = request.getParameter("id");
		String password = request.getParameter("passwd");
		Adminbean loginBean=new Adminbean(username,password);
		ILoginService loginService = new LoginServiceImpl();
		if(loginService.checkAdmin(loginBean)) {
			response.sendRedirect("pages/Adminpage.jsp");
		}
		else {
			
			pw.println("You have entered wrong username or password");
            RequestDispatcher rd=request.getRequestDispatcher("AdminLogin/AdminLogin.jsp");
            rd.include(request, response);    
		}
	}

}
