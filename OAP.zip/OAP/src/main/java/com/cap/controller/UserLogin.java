package com.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cap.model.Adminbean;
import com.cap.model.UserReq;
import com.cap.service.ILoginService;
import com.cap.service.LoginServiceImpl;

@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UserLogin() {
        super();
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String username = request.getParameter("uname");
		pw.println(username);
		String password = request.getParameter("psswd");
		//UserReq loginuser=new UserReq(username,password);
		ILoginService loginService = new LoginServiceImpl();
		if(loginService.checkUser(username,password)) {
			response.sendRedirect("pages/UserPage.jsp");
		}
		else {
			
			pw.println("You have entered wrong username or password");
            RequestDispatcher rd=request.getRequestDispatcher("UserLogin/UserLogin.jsp");
            rd.include(request, response);    
		}
	}

	}


