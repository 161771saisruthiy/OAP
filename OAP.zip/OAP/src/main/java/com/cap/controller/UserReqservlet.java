package com.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cap.model.UserReq;
import com.cap.service.ILoginService;
import com.cap.service.LoginServiceImpl;

@WebServlet("/UserReq")
public class UserReqservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     ILoginService loginservice=new LoginServiceImpl();  
   
    public UserReqservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String username = request.getParameter("userid");
		String firstname= request.getParameter("fname");
		String lastname= request.getParameter("lname");
		String emailid= request.getParameter("emailid");
		String psswd= request.getParameter("psswd");
		
		UserReq usreq=new UserReq(username,firstname,lastname,emailid,psswd);
		try {
			if(loginservice.createRequest(usreq)!=null) {
				response.sendRedirect("UserLogin/UserLogin.jsp");

			}
else {
				
				pw.println("unable to create account");
			    RequestDispatcher rd=request.getRequestDispatcher("UserLogin/UserLogin.jsp");
			    rd.include(request, response);    
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		
	}

}
