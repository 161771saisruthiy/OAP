package com.cap.model;

import java.io.File;

public class UploadFile {

	private String asname;
	private File filepart;
	public UploadFile() {
		super();
	}
	public UploadFile(String asname, File filepart) {
		super();
		this.asname = asname;
		this.filepart = filepart;
	}
	public String getAsname() {
		return asname;
	}
	public void setAsname(String asname) {
		this.asname = asname;
	}
	public File getFilepart() {
		return filepart;
	}
	public void setFilepart(File filepart) {
		this.filepart = filepart;
	}
	@Override
	public String toString() {
		return "UploadFile [asname=" + asname + ", filepart=" + filepart + "]";
	}
	 
	
	
}
